import { Routes } from '@angular/router';
import { ThankyouComponent } from './thankyou.component';

export const ThankyouRoutes: Routes = [{
  path: 'thankyou',
  component: ThankyouComponent,
}];
