import {Component} from '@angular/core';
import{Router} from '@angular/router';


@Component({
	selector: 'thankyou',
	templateUrl: 'app/thankyou/thankyou.template.html',
})
export class ThankyouComponent{

	constructor() {}
}