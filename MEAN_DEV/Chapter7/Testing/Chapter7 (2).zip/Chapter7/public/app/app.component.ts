import { Component } from '@angular/core';

@Component({
selector: 'mean-app',
template: '<h1>Hello World</h1>',
})
export class AppComponent {}